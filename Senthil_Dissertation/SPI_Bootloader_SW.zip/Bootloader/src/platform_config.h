#ifndef __PLATFORM_CONFIG_H_
#define __PLATFORM_CONFIG_H_

#include "xgpio.h"
#include "xuartlite.h"

#define USER_LED0 1
#define USER_LED1 2
#define GPIO_INPUT 1
#define GPIO_OUTPUT 0
#define USR_LED_CHL 1
#define AP_RESET_CHL 2
#define BOOT_STRAP_CHL 1


#endif
