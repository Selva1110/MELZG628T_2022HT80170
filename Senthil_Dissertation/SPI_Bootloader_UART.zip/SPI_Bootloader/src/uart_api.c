
#include "uart_api.h"

u32 recieved_Count,fw_size;
u8 *uart_rx_buf, *next_add;
XUartNs550 UartNs550Instance;	/* Instance of the UART Device */


void
init_uart()
{
    XUartNs550Format uart_cfg;
#ifdef STDOUT_IS_16550
	XUartNs550_Initialize(&UartNs550Instance, XPAR_UARTNS550_0_DEVICE_ID);
    uart_cfg.BaudRate = UART_BAUD;
    uart_cfg.DataBits = XUN_FORMAT_8_BITS;
    uart_cfg.Parity = XUN_FORMAT_NO_PARITY;
    uart_cfg.StopBits = XUN_FORMAT_1_STOP_BIT;
    XUartNs550_SetDataFormat(&UartNs550Instance,&uart_cfg);
    XUartNs550_SetFifoThreshold(&UartNs550Instance,XUN_FIFO_TRIGGER_14);
    XUartNs550_WriteReg(STDOUT_BASEADDR,XUN_IER_OFFSET,(XUN_IER_RX_DATA | XUN_IER_MODEM_STATUS | XUN_IER_RX_LINE | XUN_IER_TX_EMPTY));
#endif
    /* Bootrom/BSP configures PS7/PSU UART to 115200 bps */
}

int uart_recieve_fw()
{
	u8 rx_data;
	print("\n\nNOTE : Please Hit Enter to complete the commands \n\n\r");
	print("Please Enter the Main AP Firmware Size in Bytes (Allowed Size 25Kb) : ");

	do
	{
		rx_data = XUartNs550_RecvByte(STDIN_BASEADDRESS);
		if(rx_data != '\r')
			fw_size = (fw_size *10) + atoi(&rx_data);
	}while((rx_data != '\r'));
	uart_rx_buf = (u8 *)allocate_memory(fw_size);
	print("\n\nPlease Send the File \n\n ");
	next_add = uart_rx_buf;
	while(next_add < (uart_rx_buf + fw_size))
	{
			*next_add = XUartNs550_RecvByte(STDIN_BASEADDRESS);
			next_add++;
			recieved_Count++;
	}
	if(recieved_Count == fw_size)
		return XST_SUCCESS;
	else
		return XST_FAILURE;
}
