/***************************** Include Files *********************************/

#include "xparameters.h"	/* EDK generated parameters */
#include "xspi.h"		/* SPI device driver */
#include "xil_exception.h"
#include "spi_flash_drv.h"
#include "SPI_API.h"


/************************** Variable Definitions *****************************/

/*
 * The instances to support the device drivers are global such that they
 * are initialized to zero each time the program runs. They could be local
 * but should at least be static so they are zeroed.
 */
static XSpi Spi;
extern u8 *uart_rx_buf;
extern u32 fw_size;
extern int ErrorCount;
/*
 * The following variables are shared between non-interrupt processing and
 * interrupt processing such that they must be global.
 */
volatile static int TransferInProgress;
extern int wait_timeout;
/*
 * The following variable tracks any errors that occur during interrupt
 * processing.
 */


/*
 * Buffers used during read and write transactions.
 */
extern volatile u8 ReadBuffer[PAGE_SIZE];
extern volatile u8 WriteBuffer[PAGE_SIZE];



/************************** Function Definitions ******************************/

/*****************************************************************************/
/**
*
* This function enables writes to the Winbond Serial Flash memory.
*
* @param	SpiPtr is a pointer to the instance of the Spi device.
*
* @return	XST_SUCCESS if successful else XST_FAILURE.
*
* @note		None
*
******************************************************************************/
int SpiFlashWriteEnable(XSpi *SpiPtr)
{
	int Status;

	/*
	 * Wait while the Flash is busy.

//	Status = SpiFlashWaitForFlashReady();
	if(Status != XST_SUCCESS) {
		return XST_FAILURE;
	}

	/*
	 * Prepare the WriteBuffer.
	 */
	WriteBuffer[BYTE1] = COMMAND_WRITE_ENABLE;

	/*
	 * Initiate the Transfer.
	 */
	TransferInProgress = TRUE;
	Status = XSpi_Transfer(SpiPtr, WriteBuffer, NULL,
				WRITE_ENABLE_BYTES);
	if(Status != XST_SUCCESS) {
		return XST_FAILURE;
	}

	/*
	 * Wait till the Transfer is complete and check if there are any errors
	 * in the transaction..
	 */
	while(TransferInProgress)
	{
		if(wait_timeout == 0x200)
		{
			TransferInProgress = FALSE;
			break;
		}
		else
			wait_timeout++;
	}
	if(ErrorCount != 0) {
		ErrorCount = 0;
		return XST_FAILURE;
	}

	return XST_SUCCESS;
}

/*****************************************************************************/
/**
*
* This function writes the data to the specified locations in the Winbond Serial
* Flash memory.
*
* @param	SpiPtr is a pointer to the instance of the Spi device.
* @param	Addr is the address in the Buffer, where to write the data.
* @param	ByteCount is the number of bytes to be written.
* @param 	WriteCmd is the command used for writing data to flash.
*
* @return	XST_SUCCESS if successful else XST_FAILURE.
*
* @note		None
*
******************************************************************************/
int SpiFlashWrite(XSpi *SpiPtr, u32 Addr, u32 ByteCount, u8 WriteCmd)
{
	u32 Index;
	int Status;
	u8 frameSize;
	u32 RemainingBytes;
	u32 loopCount = (ByteCount/PAGE_SIZE) +1;

	/*
		 * Fill in the TEST data that is to be written into the Winbond Serial
		 * Flash device.
		 */
	for(;loopCount>0;loopCount--){
		/*
		 * Prepare the WriteBuffer.
		 */

		SpiFlashWriteEnable(SpiPtr);
		WriteBuffer[BYTE1] = WriteCmd;
		WriteBuffer[BYTE2] = (u8) (Addr >> 16);
		WriteBuffer[BYTE3] = (u8) (Addr >> 8);
		WriteBuffer[BYTE4] = (u8) Addr;
		RemainingBytes = ByteCount - ((((ByteCount/PAGE_SIZE) +1) - loopCount)* PAGE_SIZE);
		frameSize =  ((RemainingBytes < (PAGE_SIZE - READ_WRITE_EXTRA_BYTES))? RemainingBytes : (PAGE_SIZE - READ_WRITE_EXTRA_BYTES));
		for(Index = 4; Index < frameSize + READ_WRITE_EXTRA_BYTES; Index++) {
			WriteBuffer[Index] = *(uart_rx_buf + (Index - READ_WRITE_EXTRA_BYTES) + ((((ByteCount/PAGE_SIZE) +1) - loopCount)* PAGE_SIZE));
		}
		/*
		 * Initiate the Transfer.
		 */
		TransferInProgress = TRUE;
		Status = XSpi_Transfer(SpiPtr, WriteBuffer, NULL,(frameSize + READ_WRITE_EXTRA_BYTES));
		if(Status != XST_SUCCESS) {
			return XST_FAILURE;
		}
		Addr +=  PAGE_SIZE;
	}


	/*
	 * Wait till the Transfer is complete and check if there are any errors
	 * in the transaction.
	 */
	while(TransferInProgress)
		{
			if(wait_timeout == 0x200)
			{
				TransferInProgress = FALSE;
				break;
			}
			else
				wait_timeout++;
		}
	if(ErrorCount != 0) {
		ErrorCount = 0;
		return XST_FAILURE;
	}

	return XST_SUCCESS;
}


int SpiFlashKeywordWrite(XSpi *SpiPtr)
{
	int Status;
	SpiFlashWriteEnable(SpiPtr);
	WriteBuffer[BYTE1] = COMMAND_PAGE_PROGRAM;
	WriteBuffer[BYTE2] = (u8) (FLASH_KEYWORD_ADDRESS >> 16);
	WriteBuffer[BYTE3] = (u8) (FLASH_KEYWORD_ADDRESS >> 8);
	WriteBuffer[BYTE4] = (u8) FLASH_KEYWORD_ADDRESS;
	WriteBuffer[BYTE5] = (u8) (fw_size >> 24);
	WriteBuffer[BYTE6] = (u8) (fw_size >> 16);
	WriteBuffer[BYTE7] = (u8) (fw_size >> 8);
	WriteBuffer[BYTE8] = (u8) (fw_size);
	WriteBuffer[BYTE9] = (u8) (FLASH_KEYWORD >> 24);
	WriteBuffer[BYTE10] = (u8) (FLASH_KEYWORD >> 16);
	WriteBuffer[BYTE11] = (u8) (FLASH_KEYWORD >> 8);
	WriteBuffer[BYTE12] = (u8) (FLASH_KEYWORD);
	TransferInProgress = TRUE;
	Status = XSpi_Transfer(SpiPtr, WriteBuffer, NULL,(FLASH_KEYWORD_SIZE + READ_WRITE_EXTRA_BYTES));
	if(Status != XST_SUCCESS) {
		return XST_FAILURE;
	}
	return XST_SUCCESS;
}



int SpiFlashKeywordRead(XSpi *SpiPtr , u32 *size, u32 *Keyword)
{
	int Status;

	/*
	 * Prepare the WriteBuffer.
	 */
	ReadBuffer[BYTE1] = COMMAND_RANDOM_READ;
	ReadBuffer[BYTE2] = (u8) (FLASH_KEYWORD_ADDRESS >> 16);
	ReadBuffer[BYTE3] = (u8) (FLASH_KEYWORD_ADDRESS >> 8);
	ReadBuffer[BYTE4] = (u8) FLASH_KEYWORD_ADDRESS;
	TransferInProgress = TRUE;
	Status = XSpi_Transfer(SpiPtr, ReadBuffer, ReadBuffer,(FLASH_KEYWORD_SIZE + READ_WRITE_EXTRA_BYTES));
	*size = (ReadBuffer[BYTE5] * 0x1000000) + (ReadBuffer[BYTE6] * 0x10000) + (ReadBuffer[BYTE7] * 0x100) + (ReadBuffer[BYTE8]);
	*Keyword = (ReadBuffer[BYTE9] * 0x1000000) + (ReadBuffer[BYTE10] * 0x10000) + (ReadBuffer[BYTE11] * 0x100) + ReadBuffer[BYTE12];
	//(u64)((ReadBuffer[BYTE12] || ((u64)ReadBuffer[BYTE11] << 8) || ((u64)ReadBuffer[BYTE10] << 16)|| ((u64)ReadBuffer[BYTE9] << 24)|| ((u64)ReadBuffer[BYTE8] << 32)|| ((u64)ReadBuffer[BYTE7] << 40)|| ((u64)ReadBuffer[BYTE6] << 48)|| ((u64)ReadBuffer[BYTE5] << 56)));
	if(Status != XST_SUCCESS) {
		return XST_FAILURE;
	}
	return XST_SUCCESS;
}


/*****************************************************************************/
/**
*
* This function reads the data from the Winbond Serial Flash Memory
*
* @param	SpiPtr is a pointer to the instance of the Spi device.
* @param	Addr is the starting address in the Flash Memory from which the
*		data is to be read.
* @param	ByteCount is the number of bytes to be read.
* @param	ReadCmd is the command used for reading data from flash.
*
* @return	XST_SUCCESS if successful else XST_FAILURE.
*
* @note		None
*
******************************************************************************/
int SpiFlashRead(XSpi *SpiPtr, u32 Addr, u32 ByteCount, u8 ReadCmd)
{
	u32 Index;
	int Status;
	u8 frameSize;
	u32 RemainingBytes;
	u32 loopCount = (ByteCount/PAGE_SIZE) +1;


	for(;loopCount>0;loopCount--){

	/*
	 * Clear the read Buffer.
	 */
	for(Index = 0; Index < PAGE_SIZE + READ_WRITE_EXTRA_BYTES; Index++) {
		ReadBuffer[Index] = 0x0;
	}
	/*
	 * Prepare the WriteBuffer.
	 */
	ReadBuffer[BYTE1] = ReadCmd;
	ReadBuffer[BYTE2] = (u8) (Addr >> 16);
	ReadBuffer[BYTE3] = (u8) (Addr >> 8);
	ReadBuffer[BYTE4] = (u8) Addr;
	RemainingBytes = ByteCount - ((((ByteCount/PAGE_SIZE) +1) - loopCount)* PAGE_SIZE);
	frameSize =  ((RemainingBytes < (PAGE_SIZE - READ_WRITE_EXTRA_BYTES))? RemainingBytes : (PAGE_SIZE - READ_WRITE_EXTRA_BYTES));
	/*
	 * Initiate the Transfer.
	 */
	TransferInProgress = TRUE;
	XSpi_IntrGlobalDisable(SpiPtr);
	Status = XSpi_Transfer( SpiPtr, ReadBuffer, ReadBuffer,(frameSize + READ_WRITE_EXTRA_BYTES));
	if(Status != XST_SUCCESS) {
		return XST_FAILURE;
	}
	Addr +=  PAGE_SIZE;
	for(Index = 4; Index < frameSize + READ_WRITE_EXTRA_BYTES; Index++) {
		*(uart_rx_buf + 25600 + (Index - READ_WRITE_EXTRA_BYTES) + ((((ByteCount/PAGE_SIZE) +1) - loopCount)* PAGE_SIZE)) = ReadBuffer[Index];
	}
	}

	/*
	 * Wait till the Transfer is complete and check if there are any errors
	 * in the transaction.
	 */
	while(TransferInProgress)
		{
			if(wait_timeout == 0x200)
			{
				TransferInProgress = FALSE;
				break;
			}
			else
				wait_timeout++;
		}
	if(ErrorCount != 0) {
		ErrorCount = 0;
		return XST_FAILURE;
	}

	return XST_SUCCESS;
}

/*****************************************************************************/
/**
*
* This function erases the contents of the specified Sector in the Winbond
* Serial Flash device.
*
* @param	SpiPtr is a pointer to the instance of the Spi device.
* @param	Addr is the address within a sector of the Buffer, which is to
*		be erased.
*
* @return	XST_SUCCESS if successful else XST_FAILURE.
*
* @note		The erased bytes will be read back as 0xFF.
*
******************************************************************************/
int SpiFlashSectorErase(XSpi *SpiPtr, u32 Addr)
{
	int Status;

	/*
	 * Prepare the WriteBuffer.
	 */
	WriteBuffer[BYTE1] = COMMAND_SECTOR_ERASE;
	WriteBuffer[BYTE2] = (u8) (Addr >> 16);
	WriteBuffer[BYTE3] = (u8) (Addr >> 8);
	WriteBuffer[BYTE4] = (u8) (Addr);

	/*
	 * Initiate the Transfer.
	 */
	TransferInProgress = TRUE;
	Status = XSpi_Transfer(SpiPtr, WriteBuffer, NULL,
					SECTOR_ERASE_BYTES);
	if(Status != XST_SUCCESS) {
		return XST_FAILURE;
	}

	/*
	 * Wait till the Transfer is complete and check if there are any errors
	 * in the transaction..
	 */
	while(TransferInProgress)
		{
			if(wait_timeout == 0x200)
			{
				TransferInProgress = FALSE;
				break;
			}
			else
				wait_timeout++;
		}
	if(ErrorCount != 0) {
		ErrorCount = 0;
		return XST_FAILURE;
	}

	return XST_SUCCESS;
}

/*****************************************************************************/
/**
*
* This function reads the Status register of the Winbond Flash.
*
* @param	SpiPtr is a pointer to the instance of the Spi device.
*
* @return	XST_SUCCESS if successful else XST_FAILURE.
*
* @note		The status register content is stored at the second byte pointed
*		by the ReadBuffer.
*
******************************************************************************/
int SpiFlashGetStatus(XSpi *SpiPtr)
{
	int Status;

	/*
	 * Prepare the Write Buffer.
	 */
	WriteBuffer[BYTE1] = COMMAND_STATUSREG_READ;
	ReadBuffer[BYTE1] = 0xff;
	/*
	 * Initiate the Transfer.
	 */
	TransferInProgress = TRUE;
	XSpi_IntrGlobalDisable(SpiPtr);
	Status = XSpi_Transfer(SpiPtr, WriteBuffer, ReadBuffer,
						STATUS_READ_BYTES);
	if(Status != XST_SUCCESS) {
		return XST_FAILURE;
	}

	/*
	 * Wait till the Transfer is complete and check if there are any errors
	 * in the transaction..
	 */
	if(ErrorCount != 0) {
		ErrorCount = 0;
		return XST_FAILURE;
	}

	return XST_SUCCESS;
}

/*****************************************************************************/
/**
*
* This function waits till the Winbond serial Flash is ready to accept next
* command.
*
* @param	None
*
* @return	XST_SUCCESS if successful else XST_FAILURE.
*
* @note		This function reads the status register of the Buffer and waits
*.		till the WIP bit of the status register becomes 0.
*
******************************************************************************/
int SpiFlashWaitForFlashReady(void)
{
	int Status;
	u8 StatusReg;

	while(1) {

		/*
		 * Get the Status Register.
		 */
		Status = SpiFlashGetStatus(&Spi);
		if(Status != XST_SUCCESS) {
			return XST_FAILURE;
		}

		/*
		 * Check if the flash is ready to accept the next command.
		 * If so break.
		 */
		StatusReg = ReadBuffer[1];
		if((StatusReg & FLASH_SR_IS_READY_MASK) == 0) {
			break;
		}
	}

	return XST_SUCCESS;
}



/*****************************************************************************/
/**
*
* This function waits till the Winbond serial Flash is ready to accept next
* command.
*
* @param	None
*
* @return	XST_SUCCESS if successful else XST_FAILURE.
*
* @note		This function reads the status register of the Buffer and waits
*.		till the WIP bit of the status register becomes 0.
*
******************************************************************************/
int Is_FlashReady(XSpi *SpiPtr)
{
	int Status;
	u8 StatusReg;
	int loopcount;
	while(1) {

		/*
		 * Get the Status Register.
		 */
		Status = SpiFlashGetStatus(SpiPtr);
		if(Status != XST_SUCCESS) {
			return XST_FAILURE;
		}

		/*
		 * Check if the flash is ready to accept the next command.
		 * If so break.
		 */
		StatusReg = ReadBuffer[1];
		if((StatusReg & FLASH_SR_IS_READY_MASK) == 0) {
			break;
		}
		// delay for 30 ms
		for(loopcount = 0;loopcount <= 100000;loopcount++);

	}

	return XST_SUCCESS;
}



/*****************************************************************************/
/**
*
* This function sets the QuadEnable bit in Winbond flash.
*
* @param	SpiPtr is a pointer to the instance of the Spi device.
*
* @return	XST_SUCCESS if successful else XST_FAILURE.
*
* @note		None.
*
******************************************************************************/
int SpiFlashQuadEnable(XSpi *SpiPtr)
{
	int Status;

	/*
	 * Perform the Write Enable operation.
	 */
	Status = SpiFlashWriteEnable(SpiPtr);
	if(Status != XST_SUCCESS) {
		return XST_FAILURE;
	}

	/*
	 * Wait while the Flash is busy.
	 */
	Status = SpiFlashWaitForFlashReady();
	if(Status != XST_SUCCESS) {
		return XST_FAILURE;
	}

	/*
	 * Prepare the WriteBuffer.
	 */
	WriteBuffer[BYTE1] = 0x01;
	WriteBuffer[BYTE2] = 0x00;
	WriteBuffer[BYTE3] = 0x02; /* QE = 1 */

	/*
	 * Initiate the Transfer.
	 */
	TransferInProgress = TRUE;
	Status = XSpi_Transfer(SpiPtr, WriteBuffer, NULL, 3);
	if(Status != XST_SUCCESS) {
		return XST_FAILURE;
	}

	/*
	 * Wait till the Transfer is complete and check if there are any errors
	 * in the transaction..
	 */
	while(TransferInProgress);
	if(ErrorCount != 0) {
		ErrorCount = 0;
		return XST_FAILURE;
	}

	/*
	 * Wait while the Flash is busy.
	 */
	Status = SpiFlashWaitForFlashReady();
	if(Status != XST_SUCCESS) {
		return XST_FAILURE;
	}

	/*
	 * Verify that QE bit is set by reading status register 2.
	 */

	/*
	 * Prepare the Write Buffer.
	 */
	WriteBuffer[BYTE1] = 0x35;

	/*
	 * Initiate the Transfer.
	 */
	TransferInProgress = TRUE;
	Status = XSpi_Transfer(SpiPtr, WriteBuffer, ReadBuffer,
						STATUS_READ_BYTES);
	if(Status != XST_SUCCESS) {
		return XST_FAILURE;
	}

	/*
	 * Wait till the Transfer is complete and check if there are any errors
	 * in the transaction..
	 */
	while(TransferInProgress);
	if(ErrorCount != 0) {
		ErrorCount = 0;
		return XST_FAILURE;
	}

	return XST_SUCCESS;
}


