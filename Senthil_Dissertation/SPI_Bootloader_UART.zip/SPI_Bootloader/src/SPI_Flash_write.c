/************************** Include Files *****************************/
#include <stdio.h>
#include "platform.h"
#include "xspi.h"
#include "spi_flash_drv.h"
#include "SPI_API.h"


/************************** Variable Definitions *****************************/

/*
 * The instances to support the device drivers are global such that they
 * are initialized to zero each time the program runs. They could be local
 * but should at least be static so they are zeroed.
 */

/*
 * Byte offset value written to Flash. This needs to be redefined for writing
 * different patterns of data to the Flash device.
 */
static XSpi Spi;
extern u32 fw_size;
u8 ReadBuffer[PAGE_SIZE];
u8 WriteBuffer[PAGE_SIZE];
//volatile u8 CommandBuffer[PAGE_SIZE + READ_WRITE_EXTRA_BYTES];
static int TransferInProgress;
int ErrorCount;
int wait_timeout;
/************************** Test Definitions *****************************/

/*****************************************************************************/
/**
*
* This function is the handler which performs processing for the SPI driver.
* It is called from an interrupt context such that the amount of processing
* performed should be minimized. It is called when a transfer of SPI data
* completes or an error occurs.
*
* This handler provides an example of how to handle SPI interrupts and
* is application specific.
*
* @param	CallBackRef is the upper layer callback reference passed back
*		when the callback function is invoked.
* @param	StatusEvent is the event that just occurred.
* @param	ByteCount is the number of bytes transferred up until the event
*		occurred.
*
* @return	None.
*
* @note		None.
*
******************************************************************************/
void SpiHandler(void *CallBackRef, u32 StatusEvent, unsigned int ByteCount)
{
	/*
	 * Indicate the transfer on the SPI bus is no longer in progress
	 * regardless of the status event.
	 */
	TransferInProgress = FALSE;

	/*
	 * If the event was not transfer done, then track it as an error.
	 */
	if (StatusEvent != XST_SPI_TRANSFER_DONE) {
		ErrorCount++;
	}
}
int spi_flash_write(void)
{
	int Status;
	u32 Index;
	u32 Data;
	XSpi_Config *ConfigPtr;	/* Pointer to Configuration data */
	/*
	 * Initialize the SPI driver so that it's ready to use,
	 * specify the device ID that is generated in xparameters.h.
	 */
	ConfigPtr = XSpi_LookupConfig(SPI_DEVICE_ID);
	if (ConfigPtr == NULL) {
		return XST_DEVICE_NOT_FOUND;
	}

	Status = XSpi_CfgInitialize(&Spi, ConfigPtr,
				  ConfigPtr->BaseAddress);
	if(Status == XST_SUCCESS)
		print(" SPI Initialization Success \r\n");
	else
		print(" SPI Initialization Failed \r\n");

	Status = XSpi_SetOptions(&Spi, XSP_MASTER_OPTION );
	if(Status != XST_SUCCESS) {
		return XST_FAILURE;
	}

	Status = XSpi_SetSlaveSelect(&Spi, SPI_SELECT);
	if(Status != XST_SUCCESS) {
		return XST_FAILURE;
	}


	 Spi.IsStarted = XIL_COMPONENT_IS_STARTED;

	 /* Reset the transmit and receive FIFOs if present. There is a critical
	 * section here since this register is also modified during interrupt
	 * context. So we wait until after the r/m/w of the control register to
	 * enable the Global Interrupt Enable.*/

	Data = XSpi_GetControlReg(&Spi);
	Data |= XSP_CR_TXFIFO_RESET_MASK | XSP_CR_RXFIFO_RESET_MASK |
			XSP_CR_ENABLE_MASK;
	XSpi_SetControlReg(&Spi, Data);

	/*
	 * Perform the Write Enable operation.
	 */
	Status = SpiFlashWriteEnable(&Spi);
	if(Status == XST_SUCCESS)
			print(" SPI Flash Write Enable Command Issued \r\n");

	/*
	 * Perform the Sector Erase operation.
	 */
	Status = SpiFlashSectorErase(&Spi, FLASH_TEST_ADDRESS);
	if(Status == XST_SUCCESS)
			print(" SPI Flash Sector Erase Command Issued \r\n");

	Status = Is_FlashReady(&Spi);
	if(Status == XST_SUCCESS)
			print(" SPI Flash Sector Erase Completed \r\n");

	/*
	 * Write the data to the Page using Page Program command.
	 */
	Status = SpiFlashWrite(&Spi, FLASH_TEST_ADDRESS, fw_size, COMMAND_PAGE_PROGRAM);
	if(Status == XST_SUCCESS)
			print(" Firmware written into Flash \r\n");

	Status = SpiFlashKeywordWrite(&Spi);
		if(Status == XST_SUCCESS)
				print(" Firmware Keyword written into Flash \r\n");

	/*
	 * Read the data from the Page using Random Read command.
	 */
	Status = SpiFlashRead(&Spi, FLASH_TEST_ADDRESS, fw_size, COMMAND_RANDOM_READ);
	if(Status == XST_SUCCESS)
			print(" Test data pattern Read back from Flash \r\n");

	return XST_SUCCESS;
}


int spi_flash_read(void)
{
	int Status;
	u32 Index;
	u32 Data;
	u32 Keyword;
	XSpi_Config *ConfigPtr;	/* Pointer to Configuration data */
	/*
	 * Initialize the SPI driver so that it's ready to use,
	 * specify the device ID that is generated in xparameters.h.
	 */
	if(Spi.IsStarted != XIL_COMPONENT_IS_STARTED)
	{
		ConfigPtr = XSpi_LookupConfig(SPI_DEVICE_ID);
		if (ConfigPtr == NULL) {
			return XST_DEVICE_NOT_FOUND;
		}

		Status = XSpi_CfgInitialize(&Spi, ConfigPtr,
					  ConfigPtr->BaseAddress);
		if(Status == XST_SUCCESS)
			print(" SPI Initialization Success \r\n");
		else
			print(" SPI Initialization Failed \r\n");

		Status = XSpi_SetOptions(&Spi, XSP_MASTER_OPTION );
		if(Status != XST_SUCCESS) {
			return XST_FAILURE;
		}

		Status = XSpi_SetSlaveSelect(&Spi, SPI_SELECT);
		if(Status != XST_SUCCESS) {
			return XST_FAILURE;
		}


		 Spi.IsStarted = XIL_COMPONENT_IS_STARTED;

		 /* Reset the transmit and receive FIFOs if present. There is a critical
		 * section here since this register is also modified during interrupt
		 * context. So we wait until after the r/m/w of the control register to
		 * enable the Global Interrupt Enable.*/

		Data = XSpi_GetControlReg(&Spi);
		Data |= XSP_CR_TXFIFO_RESET_MASK | XSP_CR_RXFIFO_RESET_MASK |
				XSP_CR_ENABLE_MASK;
		XSpi_SetControlReg(&Spi, Data);
	}

	Status = Is_FlashReady(&Spi);
		if(Status == XST_SUCCESS)
			print(" SPI Flash Ready \r\n");

	SpiFlashKeywordRead(&Spi, &fw_size, &Keyword);//SpiFlashKeywordRead(&Spi);
		if(Keyword != FLASH_KEYWORD)
		{
			print(" Invalid Keyword Read from Flash \r\n");
		}
	Status = SpiFlashRead(&Spi, FLASH_TEST_ADDRESS, fw_size, COMMAND_RANDOM_READ);
		if(Status == XST_SUCCESS)
				print(" Test data pattern Read back from Flash \r\n");

}
