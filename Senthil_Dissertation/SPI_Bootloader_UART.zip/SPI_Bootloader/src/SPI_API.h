/***************************** Include Files *********************************/
#include <stdio.h>
#include "platform.h"
#include "xspi.h"



#define SPI_DEVICE_ID			XPAR_SPI_0_DEVICE_ID
#define INTC_DEVICE_ID			XPAR_INTC_0_DEVICE_ID

#define SPI_SELECT 			0x01

/************************** Variable Definitions *****************************/

/*
 * The instances to support the device drivers are global such that they
 * are initialized to zero each time the program runs. They could be local
 * but should at least be static so they are zeroed.
 */




void SpiHandler(void *CallBackRef, u32 StatusEvent, unsigned int ByteCount);
int spi_lb_test(void);
int spi_flash_write(void);
int spi_flash_read(void);
