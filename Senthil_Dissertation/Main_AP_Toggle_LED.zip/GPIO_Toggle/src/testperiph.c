#define GPIO_OUT_DATA 		*(int *)0x40010000
int main () 
{
  while(1)
  {
	   GPIO_OUT_DATA = 0x1;
	   for(int i = 10000;i<1;i--);
	   GPIO_OUT_DATA = 0x0;
  }
   return 0;
}
