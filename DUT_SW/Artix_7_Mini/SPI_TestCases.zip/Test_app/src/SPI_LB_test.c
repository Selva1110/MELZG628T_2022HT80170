/************************** Include Files *****************************/
#include <stdio.h>
#include "platform.h"
#include "xintc.h"
#include "xspi.h"
#include "SPI_Test.h"


/************************** Variable Definitions *****************************/

/*
 * The instances to support the device drivers are global such that they
 * are initialized to zero each time the program runs. They could be local
 * but should at least be static so they are zeroed.
 */

static XSpi Spi;
static u8 lb_data[] = {0x55, 0xAA, 0x55, 0xAA};
static u8 rx_data[4];
static int TransferInProgress;
extern int ErrorCount;
extern int wait_timeout;
/************************** Test Definitions *****************************/
int spi_lb_test(void)
{
	int Status,Index;
		XSpi_Config *ConfigPtr;	/* Pointer to Configuration data */

		/*
		 * Initialize the SPI driver so that it's ready to use,
		 * specify the device ID that is generated in xparameters.h.
		 */
		ConfigPtr = XSpi_LookupConfig(SPI_DEVICE_ID);
		if (ConfigPtr == NULL) {
			return XST_DEVICE_NOT_FOUND;
		}

		Status = XSpi_CfgInitialize(&Spi, ConfigPtr,
					  ConfigPtr->BaseAddress);
		if(Status == XST_SUCCESS)
			print_log(" SPI Initialization Success \r\n");
		else
			print_log(" SPI Initialization Failed \r\n");


		/*
		 * Connect the SPI driver to the interrupt subsystem such that
		 * interrupts can occur. This function is application specific.
		 */
		Status = SetupInterruptSystem(&Spi);
		if(Status == XST_SUCCESS)
			print_log(" SPI Interrupt Initialization Success \r\n");
		else
			print_log(" SPI Interrupt Initialization Failed \r\n");


		/*
		 * Setup the handler for the SPI that will be called from the interrupt
		 * context when an SPI status occurs, specify a pointer to the SPI
		 * driver instance as the callback reference so the handler is able to
		 * access the instance data.
		 */
		XSpi_SetStatusHandler(&Spi, &Spi, (XSpi_StatusHandler)SpiHandler);

		/*
		 * Set the SPI device as a master and in manual slave select mode such
		 * that the slave select signal does not toggle for every byte of a
		 * transfer, this must be done before the slave select is set.
		 */
		Status = XSpi_SetOptions(&Spi, XSP_MASTER_OPTION | XSP_LOOPBACK_OPTION |
					 XSP_MANUAL_SSELECT_OPTION);

		if(Status == XST_SUCCESS)
				print_log(" SPI Loopback Enabled \r\n");

		TransferInProgress =TRUE;
		/*
		 * Start the SPI driver so that interrupts and the device are enabled.
		 */
		XSpi_Start(&Spi);

		XSpi_Transfer(&Spi, &lb_data, &rx_data, sizeof(lb_data));
		while(TransferInProgress){
			if(wait_timeout == 0x200)
			{
				TransferInProgress = FALSE;
				break;
			}
			else
				wait_timeout++;
		}
		for(Index = 0; Index < 4; Index++) {
				if(rx_data[Index] != lb_data[Index]) {
					print_log("SPI Loopback Data Integrity Failed \r\n");
					break;
				}
			}

		print_log("Successfully ran SPI Loopback test\r\n");
		return Status;
}
