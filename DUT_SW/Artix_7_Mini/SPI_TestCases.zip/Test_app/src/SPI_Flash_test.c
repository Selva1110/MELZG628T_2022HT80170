/************************** Include Files *****************************/
#include <stdio.h>
#include "platform.h"
#include "xintc.h"
#include "xspi.h"
#include "SPI_Test.h"
#include "spi_flash_drv.h"


/************************** Variable Definitions *****************************/

/*
 * The instances to support the device drivers are global such that they
 * are initialized to zero each time the program runs. They could be local
 * but should at least be static so they are zeroed.
 */

/*
 * Byte offset value written to Flash. This needs to be redefined for writing
 * different patterns of data to the Flash device.
 */
static XSpi Spi;
static u8 TestByte = 0x20;
volatile u8 ReadBuffer[PAGE_SIZE + READ_WRITE_EXTRA_BYTES + 4];
volatile u8 WriteBuffer[PAGE_SIZE + READ_WRITE_EXTRA_BYTES];
volatile u8 CommandBuffer[PAGE_SIZE + READ_WRITE_EXTRA_BYTES];
static int TransferInProgress;
int ErrorCount;
int wait_timeout;
/************************** Test Definitions *****************************/

/*****************************************************************************/
/**
*
* This function is the handler which performs processing for the SPI driver.
* It is called from an interrupt context such that the amount of processing
* performed should be minimized. It is called when a transfer of SPI data
* completes or an error occurs.
*
* This handler provides an example of how to handle SPI interrupts and
* is application specific.
*
* @param	CallBackRef is the upper layer callback reference passed back
*		when the callback function is invoked.
* @param	StatusEvent is the event that just occurred.
* @param	ByteCount is the number of bytes transferred up until the event
*		occurred.
*
* @return	None.
*
* @note		None.
*
******************************************************************************/
void SpiHandler(void *CallBackRef, u32 StatusEvent, unsigned int ByteCount)
{
	/*
	 * Indicate the transfer on the SPI bus is no longer in progress
	 * regardless of the status event.
	 */
	TransferInProgress = FALSE;

	/*
	 * If the event was not transfer done, then track it as an error.
	 */
	if (StatusEvent != XST_SPI_TRANSFER_DONE) {
		ErrorCount++;
	}
}
int spi_flash_test(void)
{
	int Status;
	u32 Index;
	u32 Address;
	XSpi_Config *ConfigPtr;	/* Pointer to Configuration data */

	/*
	 * Initialize the SPI driver so that it's ready to use,
	 * specify the device ID that is generated in xparameters.h.
	 */
	ConfigPtr = XSpi_LookupConfig(SPI_DEVICE_ID);
	if (ConfigPtr == NULL) {
		return XST_DEVICE_NOT_FOUND;
	}

	Status = XSpi_CfgInitialize(&Spi, ConfigPtr,
				  ConfigPtr->BaseAddress);
	if(Status == XST_SUCCESS)
		print_log(" SPI Initialization Success \r\n");
	else
		print_log(" SPI Initialization Failed \r\n");


	/*
	 * Connect the SPI driver to the interrupt subsystem such that
	 * interrupts can occur. This function is application specific.
	 */
	Status = SetupInterruptSystem(&Spi);
	if(Status == XST_SUCCESS)
		print_log(" SPI Interrupt Initialization Success \r\n");
	else
		print_log(" SPI Interrupt Initialization Failed \r\n");

	/*
	 * Setup the handler for the SPI that will be called from the interrupt
	 * context when an SPI status occurs, specify a pointer to the SPI
	 * driver instance as the callback reference so the handler is able to
	 * access the instance data.
	 */
	XSpi_SetStatusHandler(&Spi, &Spi, (XSpi_StatusHandler)SpiHandler);

	/*
	 * Set the SPI device as a master and in manual slave select mode such
	 * that the slave select signal does not toggle for every byte of a
	 * transfer, this must be done before the slave select is set.
	 */
	Status = XSpi_SetOptions(&Spi, XSP_MASTER_OPTION );
	if(Status != XST_SUCCESS) {
		return XST_FAILURE;
	}

	/*
	 * Select the quad flash device on the SPI bus, so that it can be
	 * read and written using the SPI bus.
	 */
	Status = XSpi_SetSlaveSelect(&Spi, SPI_SELECT);
	if(Status != XST_SUCCESS) {
		return XST_FAILURE;
	}

	/*
	 * Start the SPI driver so that interrupts and the device are enabled.
	 */
	XSpi_Start(&Spi);

	/*
	 * Specify the address in the Quad Serial Flash for the Erase/Write/Read
	 * operations.
	 */
	Address = FLASH_TEST_ADDRESS;

	/*
	 * Perform the Write Enable operation.
	 */
	Status = SpiFlashWriteEnable(&Spi);
	if(Status == XST_SUCCESS)
			print_log(" SPI Flash Write Enable Command Issued \r\n");

	/*
	 * Perform the Sector Erase operation.
	 */
	Status = SpiFlashSectorErase(&Spi, Address);
	if(Status == XST_SUCCESS)
			print_log(" SPI Flash Sector Erase Command Issued \r\n");

	Status = Is_FlashReady(&Spi);

	if(Status == XST_SUCCESS)
			print_log(" SPI Flash Sector Erase Completed \r\n");

	Status = SpiFlashWriteEnable(&Spi);
	if(Status == XST_SUCCESS)
			print_log(" SPI Flash Write Enable Command Issued \r\n");

	/*
	 * Write the data to the Page using Page Program command.
	 */
	Status = SpiFlashWrite(&Spi, Address, PAGE_SIZE, COMMAND_PAGE_PROGRAM);
	if(Status == XST_SUCCESS)
			print_log(" Test data pattern written into Flash \r\n");

	/*
	 * Clear the read Buffer.
	 */
	for(Index = 0; Index < PAGE_SIZE + READ_WRITE_EXTRA_BYTES; Index++) {
		ReadBuffer[Index] = 0x0;
	}

	/*
	 * Read the data from the Page using Random Read command.
	 */
	Status = SpiFlashRead(&Spi, Address, PAGE_SIZE, COMMAND_RANDOM_READ);
	if(Status == XST_SUCCESS)
			print_log(" Test data pattern Read back from Flash \r\n");

	/*
	 * Compare the data read against the data written.
	 */
	for(Index = 0; Index < PAGE_SIZE; Index++) {
		if(ReadBuffer[Index + READ_WRITE_EXTRA_BYTES] !=
					(u8)(Index + TestByte)) {
			return XST_FAILURE;
		}
	}

	if(Status == XST_SUCCESS)
			print_log(" Test data pattern integrity Pass \r\n");

	return XST_SUCCESS;
}
