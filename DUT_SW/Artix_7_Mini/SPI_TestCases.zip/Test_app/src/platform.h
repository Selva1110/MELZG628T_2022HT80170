#ifndef __PLATFORM_H_
#define __PLATFORM_H_
/***************************** Include Files *********************************/
#include "platform_config.h"
#include "xtmrctr.h"
#include "xintc.h"
#include "xgpio.h"
#include "xuartlite.h"


#define GPIO_DEVICE_ID  		XPAR_AXI_GPIO_0_DEVICE_ID
#define INTC_DEVICE_ID		  	XPAR_INTC_0_DEVICE_ID
#define TIMER_DEVICE_ID			XPAR_AXI_TIMER_0_DEVICE_ID
#define UART_DEVICE_ID			XPAR_UARTLITE_0_DEVICE_ID


#define TMRCTR_INTERRUPT_ID		XPAR_INTC_0_TMRCTR_0_VEC_ID


#define Output_Pin 				1  		/*LED button*/





int init_Tmr();
int init_gpio();
int init_platform();
void cleanup_platform();


static void TimerCounterHandler(void *CallBackRef, u8 TmrCtrNumber);
#endif
